// by ᴏxᴀʟʟɪᴇᴅ - xᴅ
// req fitur? chat 083852553128
// DILARANG JUAL BELIKAN!!!
// JANGAN DIHAPUS!!!

import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
  ['6283852553128', 'нuтᴀo - xᴅ', true]
] //Numeros de owner 

global.mods = ['447389645857'] 
global.prems = ['447389645857']
global.ibeng = ['YOUR_APIKEY']
global.skizo = ['YOUR_APIKEY']
global.btc = ['YOUR_APIKEY']
global.yanzbotz = ['YOUR_APIKEY']
global.neoxr = ['YOUR_APIKEY']
global.lolkey = ['GataDios'] //gw kasih apikey fremium😂

global.APIs = { // API Prefix
  // name: 'https://website'
  xteam: 'https://api.xteam.xyz', 
  nrtm: 'https://fg-nrtm.ddns.net',
  bg: 'http://bochil.ddns.net',
  fgmods: 'https://api.fgmods.xyz'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'd90a9e986e18778b',
  'https://zenzapis.xyz': '675e34de8a', 
  'https://api.fgmods.xyz': 'dEBWvxCY' //--- 100 de límite diario --- Regístrese en https://api.fgmods.xyz/
}

// Sticker WM
global.packname = 'нuтᴀo - xᴅ' 
global.author = '447389645857' 
global.fgig = '▢ Sígueme en Instagram\nhttps://www.instagram.com/'
global.dygp = ''
global.fgsc = 'https://github.com/' 
global.fgyt = 'https://youtube.com/'
global.fgpyp = 'https://paypal.me/'
global.fglog = 'https://i.imgur.com/Owmb93c.png' 

global.wait = 'ʟᴏᴀᴅɪɴɢ ᴄᴏᴍᴘʟɪᴄᴀᴛᴇᴅ нuтᴀo - xᴅ...'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // máxima advertencias

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
